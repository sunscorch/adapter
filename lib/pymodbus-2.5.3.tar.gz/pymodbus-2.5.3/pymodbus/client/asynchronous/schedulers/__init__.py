"""
Backend schedulers to use with generic Async clients
"""
from __future__ import unicode_literals


REACTOR = "reactor"
IO_LOOP = "io_loop"
ASYNC_IO = "async_io"
